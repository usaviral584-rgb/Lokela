package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.TypeConverter
import com.example.data.model.MediaType

class Converters {
  @TypeConverter
  fun fromStringList(value: List<String>?): String {
    return value?.joinToString("|||") ?: ""
  }

  @TypeConverter
  fun toStringList(value: String?): List<String> {
    if (value.isNullOrEmpty()) return emptyList()
    return value.split("|||")
  }
}

@Entity(tableName = "posts")
data class PostEntity(
  @PrimaryKey val id: String,
  val userId: String,
  val username: String,
  val userDisplayName: String,
  val userAvatar: String,
  val caption: String,
  val location: String,
  val mediaUrls: List<String>,
  val mediaType: String,
  val likeCount: Int,
  val isLiked: Boolean,
  val commentCount: Int,
  val saveCount: Int,
  val isSaved: Boolean,
  val timestamp: Long,
  val hashtags: List<String>,
  val mentions: List<String>,
  val privacy: String
)

@Entity(tableName = "short_videos")
data class ShortVideoEntity(
  @PrimaryKey val id: String,
  val userId: String,
  val username: String,
  val userDisplayName: String,
  val userAvatar: String,
  val videoUrl: String,
  val thumbnailUrl: String,
  val caption: String,
  val soundTrack: String,
  val likeCount: Int,
  val isLiked: Boolean,
  val commentCount: Int,
  val shareCount: Int,
  val isSaved: Boolean,
  val isFollowing: Boolean,
  val timestamp: Long
)

@Entity(tableName = "messages")
data class MessageEntity(
  @PrimaryKey val id: String,
  val conversationId: String,
  val senderId: String,
  val text: String,
  val mediaUrl: String?,
  val timestamp: Long,
  val status: String,
  val isMe: Boolean
)

@Entity(tableName = "notifications")
data class NotificationEntity(
  @PrimaryKey val id: String,
  val type: String,
  val title: String,
  val message: String,
  val avatarUrl: String,
  val timestamp: Long,
  val isRead: Boolean,
  val targetId: String?
)
