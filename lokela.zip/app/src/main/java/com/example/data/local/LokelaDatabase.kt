package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters

@Database(
  entities = [
    PostEntity::class,
    ShortVideoEntity::class,
    MessageEntity::class,
    NotificationEntity::class
  ],
  version = 1,
  exportSchema = false
)
@TypeConverters(Converters::class)
abstract class LokelaDatabase : RoomDatabase() {
  abstract fun postDao(): PostDao
  abstract fun shortVideoDao(): ShortVideoDao
  abstract fun messageDao(): MessageDao
  abstract fun notificationDao(): NotificationDao

  companion object {
    @Volatile
    private var INSTANCE: LokelaDatabase? = null

    fun getDatabase(context: Context): LokelaDatabase {
      return INSTANCE ?: synchronized(this) {
        val instance = Room.databaseBuilder(
          context.applicationContext,
          LokelaDatabase::class.java,
          "lokela_social_db"
        ).fallbackToDestructiveMigration().build()
        INSTANCE = instance
        instance
      }
    }
  }
}
