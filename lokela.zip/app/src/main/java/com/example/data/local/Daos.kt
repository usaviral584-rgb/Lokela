package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface PostDao {
  @Query("SELECT * FROM posts ORDER BY timestamp DESC")
  fun getAllPosts(): Flow<List<PostEntity>>

  @Query("SELECT * FROM posts WHERE id = :postId LIMIT 1")
  suspend fun getPostById(postId: String): PostEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertPosts(posts: List<PostEntity>)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertPost(post: PostEntity)

  @Query("UPDATE posts SET isLiked = :liked, likeCount = likeCount + :delta WHERE id = :postId")
  suspend fun updateLike(postId: String, liked: Boolean, delta: Int)

  @Query("UPDATE posts SET isSaved = :saved, saveCount = saveCount + :delta WHERE id = :postId")
  suspend fun updateSave(postId: String, saved: Boolean, delta: Int)

  @Query("DELETE FROM posts WHERE id = :postId")
  suspend fun deletePostById(postId: String)
}

@Dao
interface ShortVideoDao {
  @Query("SELECT * FROM short_videos ORDER BY timestamp DESC")
  fun getAllShorts(): Flow<List<ShortVideoEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertShorts(shorts: List<ShortVideoEntity>)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertShort(short: ShortVideoEntity)

  @Query("UPDATE short_videos SET isLiked = :liked, likeCount = likeCount + :delta WHERE id = :shortId")
  suspend fun updateLike(shortId: String, liked: Boolean, delta: Int)

  @Query("UPDATE short_videos SET isFollowing = :following WHERE userId = :userId")
  suspend fun updateFollowing(userId: String, following: Boolean)
}

@Dao
interface MessageDao {
  @Query("SELECT * FROM messages WHERE conversationId = :convId ORDER BY timestamp ASC")
  fun getMessagesForConversation(convId: String): Flow<List<MessageEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertMessage(message: MessageEntity)

  @Query("DELETE FROM messages WHERE conversationId = :convId")
  suspend fun deleteConversation(convId: String)
}

@Dao
interface NotificationDao {
  @Query("SELECT * FROM notifications ORDER BY timestamp DESC")
  fun getAllNotifications(): Flow<List<NotificationEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertNotifications(notifications: List<NotificationEntity>)

  @Query("UPDATE notifications SET isRead = 1 WHERE id = :id")
  suspend fun markAsRead(id: String)

  @Query("UPDATE notifications SET isRead = 1")
  suspend fun markAllAsRead()
}
