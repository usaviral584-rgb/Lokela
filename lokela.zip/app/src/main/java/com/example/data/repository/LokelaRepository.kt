package com.example.data.repository

import android.content.Context
import com.example.data.local.*
import com.example.data.model.*
import com.example.data.remote.ApiClient
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID

class LokelaRepository(private val context: Context) {
  private val database = LokelaDatabase.getDatabase(context)
  private val postDao = database.postDao()
  private val shortVideoDao = database.shortVideoDao()
  private val messageDao = database.messageDao()
  private val notificationDao = database.notificationDao()

  private val prefs = context.getSharedPreferences("lokela_auth_prefs", Context.MODE_PRIVATE)

  private val _currentUser = MutableStateFlow<User>(loadSavedUser())
  val currentUser: StateFlow<User> = _currentUser.asStateFlow()

  private val _isLoggedIn = MutableStateFlow(prefs.getBoolean("is_logged_in", true))
  val isLoggedIn: StateFlow<Boolean> = _isLoggedIn.asStateFlow()

  val posts: Flow<List<Post>> = postDao.getAllPosts().map { entities ->
    entities.map { it.toDomain() }
  }

  val shorts: Flow<List<ShortVideo>> = shortVideoDao.getAllShorts().map { entities ->
    entities.map { it.toDomain() }
  }

  val notifications: Flow<List<NotificationItem>> = notificationDao.getAllNotifications().map { entities ->
    entities.map { it.toDomain() }
  }

  init {
    CoroutineScope(Dispatchers.IO).launch {
      seedInitialDataIfEmpty()
    }
  }

  private fun loadSavedUser(): User {
    val id = prefs.getString("user_id", "user_me") ?: "user_me"
    val username = prefs.getString("username", "alex_lokela") ?: "alex_lokela"
    val displayName = prefs.getString("display_name", "Alex Rivera") ?: "Alex Rivera"
    val bio = prefs.getString("bio", "Exploring visual narratives ✨ Digital artist & creator #lokela") ?: "Exploring visual narratives ✨ Digital artist & creator #lokela"
    val avatar = prefs.getString("avatar", "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400") ?: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400"
    return User(
      id = id,
      username = username,
      displayName = displayName,
      avatarUrl = avatar,
      bio = bio,
      isVerified = true,
      followersCount = 1420,
      followingCount = 380,
      postsCount = 24
    )
  }

  suspend fun login(email: String, pass: String): Boolean = withContext(Dispatchers.IO) {
    if (email.isBlank() || pass.isBlank()) return@withContext false
    val username = email.substringBefore("@")
    val user = _currentUser.value.copy(username = username, displayName = username.replaceFirstChar { it.uppercase() })
    _currentUser.value = user
    _isLoggedIn.value = true
    prefs.edit()
      .putBoolean("is_logged_in", true)
      .putString("user_id", user.id)
      .putString("username", user.username)
      .putString("display_name", user.displayName)
      .apply()
    true
  }

  suspend fun register(email: String, pass: String, username: String, displayName: String): Boolean = withContext(Dispatchers.IO) {
    if (email.isBlank() || pass.isBlank() || username.isBlank()) return@withContext false
    val user = User(
      id = UUID.randomUUID().toString(),
      username = username,
      displayName = displayName.ifBlank { username },
      avatarUrl = "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=400",
      bio = "New to Lokela! Excited to connect & share.",
      followersCount = 0,
      followingCount = 0,
      postsCount = 0
    )
    _currentUser.value = user
    _isLoggedIn.value = true
    prefs.edit()
      .putBoolean("is_logged_in", true)
      .putString("user_id", user.id)
      .putString("username", user.username)
      .putString("display_name", user.displayName)
      .apply()
    true
  }

  suspend fun logout() = withContext(Dispatchers.IO) {
    _isLoggedIn.value = false
    prefs.edit().putBoolean("is_logged_in", false).apply()
  }

  suspend fun deleteAccount() = withContext(Dispatchers.IO) {
    _isLoggedIn.value = false
    prefs.edit().clear().apply()
  }

  suspend fun updateProfile(displayName: String, bio: String, avatarUrl: String) = withContext(Dispatchers.IO) {
    val updated = _currentUser.value.copy(
      displayName = displayName,
      bio = bio,
      avatarUrl = avatarUrl
    )
    _currentUser.value = updated
    prefs.edit()
      .putString("display_name", displayName)
      .putString("bio", bio)
      .putString("avatar", avatarUrl)
      .apply()
  }

  suspend fun toggleLikePost(postId: String) = withContext(Dispatchers.IO) {
    val post = postDao.getPostById(postId) ?: return@withContext
    val newLiked = !post.isLiked
    val delta = if (newLiked) 1 else -1
    postDao.updateLike(postId, newLiked, delta)
  }

  suspend fun toggleSavePost(postId: String) = withContext(Dispatchers.IO) {
    val post = postDao.getPostById(postId) ?: return@withContext
    val newSaved = !post.isSaved
    val delta = if (newSaved) 1 else -1
    postDao.updateSave(postId, newSaved, delta)
  }

  suspend fun toggleLikeShort(shortId: String, currentLiked: Boolean) = withContext(Dispatchers.IO) {
    val newLiked = !currentLiked
    val delta = if (newLiked) 1 else -1
    shortVideoDao.updateLike(shortId, newLiked, delta)
  }

  suspend fun toggleFollowUser(userId: String, isFollowing: Boolean) = withContext(Dispatchers.IO) {
    shortVideoDao.updateFollowing(userId, !isFollowing)
  }

  suspend fun deletePost(postId: String) = withContext(Dispatchers.IO) {
    postDao.deletePostById(postId)
  }

  suspend fun createPost(
    caption: String,
    mediaUrls: List<String>,
    mediaType: MediaType,
    location: String,
    hashtags: List<String>,
    privacy: String
  ): Post = withContext(Dispatchers.IO) {
    val me = _currentUser.value
    val newPost = Post(
      id = "post_" + UUID.randomUUID().toString().take(8),
      userId = me.id,
      username = me.username,
      userDisplayName = me.displayName,
      userAvatar = me.avatarUrl,
      caption = caption,
      location = location,
      mediaUrls = mediaUrls.ifEmpty { listOf("https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=800") },
      mediaType = mediaType,
      likeCount = 0,
      isLiked = false,
      commentCount = 0,
      saveCount = 0,
      isSaved = false,
      timestamp = System.currentTimeMillis(),
      hashtags = hashtags,
      mentions = emptyList(),
      privacy = privacy
    )
    postDao.insertPost(newPost.toEntity())
    newPost
  }

  suspend fun createShort(
    caption: String,
    videoUrl: String,
    thumbnailUrl: String,
    soundTrack: String
  ): ShortVideo = withContext(Dispatchers.IO) {
    val me = _currentUser.value
    val newShort = ShortVideo(
      id = "short_" + UUID.randomUUID().toString().take(8),
      userId = me.id,
      username = me.username,
      userDisplayName = me.displayName,
      userAvatar = me.avatarUrl,
      videoUrl = videoUrl.ifBlank { "https://assets.mixkit.co/videos/preview/mixkit-tree-branches-in-the-breeze-1188-large.mp4" },
      thumbnailUrl = thumbnailUrl.ifBlank { "https://images.unsplash.com/photo-1518770660439-4636190af475?w=800" },
      caption = caption,
      soundTrack = soundTrack.ifBlank { "Original Audio - " + me.displayName },
      likeCount = 0,
      isLiked = false,
      commentCount = 0,
      shareCount = 0,
      isSaved = false,
      isFollowing = false,
      timestamp = System.currentTimeMillis()
    )
    shortVideoDao.insertShort(newShort.toEntity())
    newShort
  }

  fun getMessages(conversationId: String): Flow<List<Message>> {
    return messageDao.getMessagesForConversation(conversationId).map { list ->
      list.map { it.toDomain() }
    }
  }

  suspend fun sendMessage(conversationId: String, text: String, mediaUrl: String? = null) = withContext(Dispatchers.IO) {
    val me = _currentUser.value
    val msg = MessageEntity(
      id = "msg_" + UUID.randomUUID().toString().take(8),
      conversationId = conversationId,
      senderId = me.id,
      text = text,
      mediaUrl = mediaUrl,
      timestamp = System.currentTimeMillis(),
      status = "sent",
      isMe = true
    )
    messageDao.insertMessage(msg)
  }

  suspend fun markNotificationAsRead(id: String) = withContext(Dispatchers.IO) {
    notificationDao.markAsRead(id)
  }

  suspend fun markAllNotificationsAsRead() = withContext(Dispatchers.IO) {
    notificationDao.markAllAsRead()
  }

  private suspend fun seedInitialDataIfEmpty() {
    val existingPosts = postDao.getPostById("p1")
    if (existingPosts != null) return

    val samplePosts = listOf(
      PostEntity(
        id = "p1",
        userId = "u_elena",
        username = "elena_craft",
        userDisplayName = "Elena Rostova",
        userAvatar = "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400",
        caption = "Exploring the neon architecture of Tokyo at twilight. Colors speak louder than words in this city. 🌌✨ #tokyonights #lokela #cyberpunk",
        location = "Shibuya, Tokyo",
        mediaUrls = listOf(
          "https://images.unsplash.com/photo-1503899036084-c55cdd92da26?w=800",
          "https://images.unsplash.com/photo-1542051841857-5f90071e7989?w=800"
        ),
        mediaType = "MULTI_IMAGE",
        likeCount = 384,
        isLiked = false,
        commentCount = 42,
        saveCount = 89,
        isSaved = false,
        timestamp = System.currentTimeMillis() - 3600000 * 2,
        hashtags = listOf("tokyonights", "lokela", "cyberpunk"),
        mentions = listOf("tokyo_urban"),
        privacy = "public"
      ),
      PostEntity(
        id = "p2",
        userId = "u_marcus",
        username = "marcus_design",
        userDisplayName = "Marcus Vance",
        userAvatar = "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400",
        caption = "Morning studio setup with new generative visual renders. Crafting the future on Lokela! 🎨🚀 #design #creativity #minimal",
        location = "Berlin Design Lab",
        mediaUrls = listOf("https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=800"),
        mediaType = "IMAGE",
        likeCount = 892,
        isLiked = true,
        commentCount = 115,
        saveCount = 230,
        isSaved = true,
        timestamp = System.currentTimeMillis() - 3600000 * 5,
        hashtags = listOf("design", "creativity", "minimal"),
        mentions = emptyList(),
        privacy = "public"
      ),
      PostEntity(
        id = "p3",
        userId = "u_sarah",
        username = "sarah_travels",
        userDisplayName = "Sarah Lin",
        userAvatar = "https://images.unsplash.com/photo-1517841905240-472988babdf9?w=400",
        caption = "Found this secluded turquoise cove along the Amalfi Coast. Life moves slower when you listen to the waves. 🌊🍋",
        location = "Amalfi Coast, Italy",
        mediaUrls = listOf("https://images.unsplash.com/photo-1533105079780-92b9be482077?w=800"),
        mediaType = "IMAGE",
        likeCount = 1240,
        isLiked = false,
        commentCount = 98,
        saveCount = 412,
        isSaved = false,
        timestamp = System.currentTimeMillis() - 3600000 * 12,
        hashtags = listOf("travel", "amalfi", "wanderlust"),
        mentions = emptyList(),
        privacy = "public"
      )
    )
    postDao.insertPosts(samplePosts)

    val sampleShorts = listOf(
      ShortVideoEntity(
        id = "s1",
        userId = "u_creator1",
        username = "beat_drop_studio",
        userDisplayName = "Kavinsky Beats",
        userAvatar = "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=400",
        videoUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
        thumbnailUrl = "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=800",
        caption = "Synthesizing dynamic low-end basslines live on Lokela 🔥🎛️ #electronic #beats #producer",
        soundTrack = "Kavinsky - Midnight Overdrive",
        likeCount = 8420,
        isLiked = false,
        commentCount = 632,
        shareCount = 1450,
        isSaved = false,
        isFollowing = false,
        timestamp = System.currentTimeMillis() - 1800000
      ),
      ShortVideoEntity(
        id = "s2",
        userId = "u_creator2",
        username = "street_skate_co",
        userDisplayName = "Kai Tanaka",
        userAvatar = "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400",
        videoUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4",
        thumbnailUrl = "https://images.unsplash.com/photo-1520045892732-304bc3ac5d8e?w=800",
        caption = "Sunset kickflip across the harbour bridge 🛹🌅 Rate the landing 1-10! #skate #sunset #lokela",
        soundTrack = "Tanaka Lo-Fi Sunrise Beats",
        likeCount = 12900,
        isLiked = true,
        commentCount = 1042,
        shareCount = 3100,
        isSaved = true,
        isFollowing = true,
        timestamp = System.currentTimeMillis() - 7200000
      ),
      ShortVideoEntity(
        id = "s3",
        userId = "u_creator3",
        username = "culinary_alchemy",
        userDisplayName = "Chef Maya",
        userAvatar = "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400",
        videoUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4",
        thumbnailUrl = "https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=800",
        caption = "Hand-pulled sourdough flatbreads with smoked garlic dip 🥖🌿 #foodie #cooking #recipe",
        soundTrack = "Acoustic Cozy Cafe Afternoon",
        likeCount = 5980,
        isLiked = false,
        commentCount = 428,
        shareCount = 920,
        isSaved = false,
        isFollowing = false,
        timestamp = System.currentTimeMillis() - 14400000
      )
    )
    shortVideoDao.insertShorts(sampleShorts)

    val sampleNotifications = listOf(
      NotificationEntity(
        id = "n1",
        type = "LIKE",
        title = "New Like",
        message = "marcus_design liked your recent photo post.",
        avatarUrl = "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400",
        timestamp = System.currentTimeMillis() - 600000,
        isRead = false,
        targetId = "p2"
      ),
      NotificationEntity(
        id = "n2",
        type = "FOLLOW",
        title = "New Follower",
        message = "elena_craft started following you on Lokela.",
        avatarUrl = "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400",
        timestamp = System.currentTimeMillis() - 3600000 * 3,
        isRead = false,
        targetId = "u_elena"
      ),
      NotificationEntity(
        id = "n3",
        type = "COMMENT",
        title = "New Comment",
        message = "sarah_travels commented: 'Stunning perspective!'",
        avatarUrl = "https://images.unsplash.com/photo-1517841905240-472988babdf9?w=400",
        timestamp = System.currentTimeMillis() - 3600000 * 6,
        isRead = true,
        targetId = "p1"
      ),
      NotificationEntity(
        id = "n4",
        type = "ANNOUNCEMENT",
        title = "Welcome to Lokela!",
        message = "Connect. Share. Discover. Your stage for authentic original creativity.",
        avatarUrl = "",
        timestamp = System.currentTimeMillis() - 86400000,
        isRead = true,
        targetId = null
      )
    )
    notificationDao.insertNotifications(sampleNotifications)

    val sampleMsg = MessageEntity(
      id = "m1",
      conversationId = "conv_1",
      senderId = "u_marcus",
      text = "Hey Alex! Loved your new series on Lokela. Are you free for a quick collab this weekend?",
      mediaUrl = null,
      timestamp = System.currentTimeMillis() - 1800000,
      status = "read",
      isMe = false
    )
    messageDao.insertMessage(sampleMsg)
  }
}

// Entity to Domain mappers
private fun PostEntity.toDomain() = Post(
  id = id,
  userId = userId,
  username = username,
  userDisplayName = userDisplayName,
  userAvatar = userAvatar,
  caption = caption,
  location = location,
  mediaUrls = mediaUrls,
  mediaType = try { MediaType.valueOf(mediaType) } catch (e: Exception) { MediaType.IMAGE },
  likeCount = likeCount,
  isLiked = isLiked,
  commentCount = commentCount,
  saveCount = saveCount,
  isSaved = isSaved,
  timestamp = timestamp,
  hashtags = hashtags,
  mentions = mentions,
  privacy = privacy
)

private fun Post.toEntity() = PostEntity(
  id = id,
  userId = userId,
  username = username,
  userDisplayName = userDisplayName,
  userAvatar = userAvatar,
  caption = caption,
  location = location,
  mediaUrls = mediaUrls,
  mediaType = mediaType.name,
  likeCount = likeCount,
  isLiked = isLiked,
  commentCount = commentCount,
  saveCount = saveCount,
  isSaved = isSaved,
  timestamp = timestamp,
  hashtags = hashtags,
  mentions = mentions,
  privacy = privacy
)

private fun ShortVideoEntity.toDomain() = ShortVideo(
  id = id,
  userId = userId,
  username = username,
  userDisplayName = userDisplayName,
  userAvatar = userAvatar,
  videoUrl = videoUrl,
  thumbnailUrl = thumbnailUrl,
  caption = caption,
  soundTrack = soundTrack,
  likeCount = likeCount,
  isLiked = isLiked,
  commentCount = commentCount,
  shareCount = shareCount,
  isSaved = isSaved,
  isFollowing = isFollowing,
  timestamp = timestamp
)

private fun ShortVideo.toEntity() = ShortVideoEntity(
  id = id,
  userId = userId,
  username = username,
  userDisplayName = userDisplayName,
  userAvatar = userAvatar,
  videoUrl = videoUrl,
  thumbnailUrl = thumbnailUrl,
  caption = caption,
  soundTrack = soundTrack,
  likeCount = likeCount,
  isLiked = isLiked,
  commentCount = commentCount,
  shareCount = shareCount,
  isSaved = isSaved,
  isFollowing = isFollowing,
  timestamp = timestamp
)

private fun MessageEntity.toDomain() = Message(
  id = id,
  conversationId = conversationId,
  senderId = senderId,
  text = text,
  mediaUrl = mediaUrl,
  timestamp = timestamp,
  status = status,
  isMe = isMe
)

private fun NotificationEntity.toDomain() = NotificationItem(
  id = id,
  type = try { NotificationType.valueOf(type) } catch (e: Exception) { NotificationType.ANNOUNCEMENT },
  title = title,
  message = message,
  avatarUrl = avatarUrl,
  timestamp = timestamp,
  isRead = isRead,
  targetId = targetId
)
