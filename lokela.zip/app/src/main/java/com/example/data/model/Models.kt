package com.example.data.model

import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class User(
  val id: String,
  val username: String,
  val displayName: String,
  val avatarUrl: String = "",
  val bio: String = "",
  val isVerified: Boolean = false,
  val isPrivate: Boolean = false,
  val followersCount: Int = 0,
  val followingCount: Int = 0,
  val postsCount: Int = 0,
  val isFollowing: Boolean = false,
  val isBlocked: Boolean = false
)

enum class MediaType {
  IMAGE,
  VIDEO,
  MULTI_IMAGE
}

@JsonClass(generateAdapter = true)
data class Post(
  val id: String,
  val userId: String,
  val username: String,
  val userDisplayName: String,
  val userAvatar: String = "",
  val caption: String = "",
  val location: String = "",
  val mediaUrls: List<String> = emptyList(),
  val mediaType: MediaType = MediaType.IMAGE,
  val likeCount: Int = 0,
  val isLiked: Boolean = false,
  val commentCount: Int = 0,
  val saveCount: Int = 0,
  val isSaved: Boolean = false,
  val timestamp: Long = System.currentTimeMillis(),
  val hashtags: List<String> = emptyList(),
  val mentions: List<String> = emptyList(),
  val privacy: String = "public"
)

@JsonClass(generateAdapter = true)
data class ShortVideo(
  val id: String,
  val userId: String,
  val username: String,
  val userDisplayName: String,
  val userAvatar: String = "",
  val videoUrl: String = "",
  val thumbnailUrl: String = "",
  val caption: String = "",
  val soundTrack: String = "Original Audio - Lokela Vibes",
  val likeCount: Int = 0,
  val isLiked: Boolean = false,
  val commentCount: Int = 0,
  val shareCount: Int = 0,
  val isSaved: Boolean = false,
  val isFollowing: Boolean = false,
  val timestamp: Long = System.currentTimeMillis()
)

@JsonClass(generateAdapter = true)
data class Comment(
  val id: String,
  val postId: String,
  val userId: String,
  val username: String,
  val userDisplayName: String,
  val userAvatar: String = "",
  val content: String,
  val timestamp: Long = System.currentTimeMillis(),
  val likeCount: Int = 0,
  val isLiked: Boolean = false,
  val repliesCount: Int = 0,
  val replies: List<CommentReply> = emptyList()
)

@JsonClass(generateAdapter = true)
data class CommentReply(
  val id: String,
  val commentId: String,
  val userId: String,
  val username: String,
  val userDisplayName: String,
  val userAvatar: String = "",
  val content: String,
  val timestamp: Long = System.currentTimeMillis(),
  val likeCount: Int = 0,
  val isLiked: Boolean = false
)

@JsonClass(generateAdapter = true)
data class Message(
  val id: String,
  val conversationId: String,
  val senderId: String,
  val text: String,
  val mediaUrl: String? = null,
  val timestamp: Long = System.currentTimeMillis(),
  val status: String = "delivered", // sent, delivered, read
  val isMe: Boolean = false
)

@JsonClass(generateAdapter = true)
data class Conversation(
  val id: String,
  val peerUser: User,
  val lastMessage: String,
  val lastTimestamp: Long = System.currentTimeMillis(),
  val unreadCount: Int = 0,
  val isOnline: Boolean = false
)

enum class NotificationType {
  LIKE,
  COMMENT,
  REPLY,
  FOLLOW,
  MENTION,
  MESSAGE,
  ANNOUNCEMENT
}

@JsonClass(generateAdapter = true)
data class NotificationItem(
  val id: String,
  val type: NotificationType,
  val title: String,
  val message: String,
  val avatarUrl: String = "",
  val timestamp: Long = System.currentTimeMillis(),
  val isRead: Boolean = false,
  val targetId: String? = null
)

@JsonClass(generateAdapter = true)
data class TrendingTopic(
  val tag: String,
  val postCount: String,
  val category: String
)
