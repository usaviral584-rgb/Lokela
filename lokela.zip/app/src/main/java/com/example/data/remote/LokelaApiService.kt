package com.example.data.remote

import com.example.data.model.*
import com.squareup.moshi.JsonClass
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.Response
import retrofit2.http.*

@JsonClass(generateAdapter = true)
data class AuthResponse(
  val success: Boolean,
  val token: String? = null,
  val refreshToken: String? = null,
  val user: User? = null,
  val message: String? = null
)

@JsonClass(generateAdapter = true)
data class LoginRequest(
  val email: String,
  val password: String
)

@JsonClass(generateAdapter = true)
data class RegisterRequest(
  val email: String,
  val password: String,
  val username: String,
  val displayName: String
)

@JsonClass(generateAdapter = true)
data class OtpRequest(
  val email: String,
  val code: String
)

@JsonClass(generateAdapter = true)
data class SendOtpRequest(
  val email: String
)

@JsonClass(generateAdapter = true)
data class ResetPasswordRequest(
  val email: String,
  val code: String,
  val newPassword: String
)

@JsonClass(generateAdapter = true)
data class CreatePostRequest(
  val caption: String,
  val mediaUrls: List<String>,
  val mediaType: String,
  val location: String,
  val hashtags: List<String>,
  val privacy: String
)

@JsonClass(generateAdapter = true)
data class AddCommentRequest(
  val postId: String,
  val content: String,
  val parentCommentId: String? = null
)

@JsonClass(generateAdapter = true)
data class SendMessageRequest(
  val conversationId: String,
  val text: String,
  val mediaUrl: String? = null
)

@JsonClass(generateAdapter = true)
data class ReportRequest(
  val targetType: String, // post, short, comment, user
  val targetId: String,
  val reason: String,
  val details: String = ""
)

@JsonClass(generateAdapter = true)
data class ApiResponse<T>(
  val success: Boolean,
  val data: T? = null,
  val message: String? = null
)

interface LokelaApiService {
  @POST("api/v1/auth/login")
  suspend fun login(@Body request: LoginRequest): Response<AuthResponse>

  @POST("api/v1/auth/register")
  suspend fun register(@Body request: RegisterRequest): Response<AuthResponse>

  @POST("api/v1/auth/otp/send")
  suspend fun sendOtp(@Body request: SendOtpRequest): Response<ApiResponse<String>>

  @POST("api/v1/auth/otp/verify")
  suspend fun verifyOtp(@Body request: OtpRequest): Response<AuthResponse>

  @POST("api/v1/auth/password/reset")
  suspend fun resetPassword(@Body request: ResetPasswordRequest): Response<ApiResponse<String>>

  @GET("api/v1/feed")
  suspend fun getHomeFeed(
    @Query("page") page: Int = 1,
    @Query("limit") limit: Int = 20
  ): Response<ApiResponse<List<Post>>>

  @POST("api/v1/posts")
  suspend fun createPost(@Body request: CreatePostRequest): Response<ApiResponse<Post>>

  @POST("api/v1/posts/{id}/like")
  suspend fun toggleLikePost(@Path("id") postId: String): Response<ApiResponse<Boolean>>

  @POST("api/v1/posts/{id}/save")
  suspend fun toggleSavePost(@Path("id") postId: String): Response<ApiResponse<Boolean>>

  @DELETE("api/v1/posts/{id}")
  suspend fun deletePost(@Path("id") postId: String): Response<ApiResponse<Boolean>>

  @GET("api/v1/shorts")
  suspend fun getShorts(
    @Query("page") page: Int = 1
  ): Response<ApiResponse<List<ShortVideo>>>

  @POST("api/v1/shorts/{id}/like")
  suspend fun toggleLikeShort(@Path("id") shortId: String): Response<ApiResponse<Boolean>>

  @GET("api/v1/posts/{id}/comments")
  suspend fun getComments(@Path("id") postId: String): Response<ApiResponse<List<Comment>>>

  @POST("api/v1/comments")
  suspend fun addComment(@Body request: AddCommentRequest): Response<ApiResponse<Comment>>

  @GET("api/v1/explore/trending")
  suspend fun getTrending(): Response<ApiResponse<List<TrendingTopic>>>

  @GET("api/v1/explore/search")
  suspend fun search(@Query("q") query: String): Response<ApiResponse<List<Post>>>

  @GET("api/v1/messages/conversations")
  suspend fun getConversations(): Response<ApiResponse<List<Conversation>>>

  @POST("api/v1/messages/send")
  suspend fun sendMessage(@Body request: SendMessageRequest): Response<ApiResponse<Message>>

  @POST("api/v1/moderation/report")
  suspend fun reportContent(@Body request: ReportRequest): Response<ApiResponse<String>>
}
