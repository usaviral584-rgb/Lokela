package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.Comment
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LokelaTopAppBar(
  onNotificationsClick: () -> Unit,
  onMessagesClick: () -> Unit,
  hasUnreadNotifications: Boolean = true,
  hasUnreadMessages: Boolean = true,
  modifier: Modifier = Modifier
) {
  TopAppBar(
    modifier = modifier.testTag("lokela_top_app_bar"),
    colors = TopAppBarDefaults.topAppBarColors(
      containerColor = MaterialTheme.colorScheme.background,
      titleContentColor = MaterialTheme.colorScheme.onBackground
    ),
    title = {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
          modifier = Modifier
            .size(32.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(
              Brush.linearGradient(
                colors = listOf(LokelaViolet, LokelaCoral)
              )
            ),
          contentAlignment = Alignment.Center
        ) {
          Text(
            text = "L",
            color = Color.White,
            fontWeight = FontWeight.Black,
            fontSize = 18.sp
          )
        }
        Spacer(modifier = Modifier.width(10.dp))
        Column {
          Text(
            text = "LOKELA",
            fontWeight = FontWeight.ExtraBold,
            fontSize = 20.sp,
            letterSpacing = 1.sp
          )
        }
      }
    },
    actions = {
      IconButton(
        onClick = onNotificationsClick,
        modifier = Modifier
          .minimumInteractiveComponentSize()
          .testTag("action_notifications")
      ) {
        Box {
          Icon(
            imageVector = Icons.Outlined.Notifications,
            contentDescription = "Notifications",
            tint = MaterialTheme.colorScheme.onBackground
          )
          if (hasUnreadNotifications) {
            Box(
              modifier = Modifier
                .size(9.dp)
                .align(Alignment.TopEnd)
                .clip(CircleShape)
                .background(LokelaCoral)
            )
          }
        }
      }

      IconButton(
        onClick = onMessagesClick,
        modifier = Modifier
          .minimumInteractiveComponentSize()
          .testTag("action_messages")
      ) {
        Box {
          Icon(
            imageVector = Icons.Outlined.ChatBubbleOutline,
            contentDescription = "Messages",
            tint = MaterialTheme.colorScheme.onBackground
          )
          if (hasUnreadMessages) {
            Box(
              modifier = Modifier
                .size(9.dp)
                .align(Alignment.TopEnd)
                .clip(CircleShape)
                .background(LokelaTeal)
            )
          }
        }
      }
    }
  )
}

enum class ScreenTab {
  HOME,
  EXPLORE,
  CREATE,
  SHORTS,
  PROFILE
}

@Composable
fun LokelaBottomNavigationBar(
  currentTab: ScreenTab,
  onTabSelected: (ScreenTab) -> Unit,
  modifier: Modifier = Modifier
) {
  NavigationBar(
    modifier = modifier
      .windowInsetsPadding(WindowInsets.navigationBars)
      .testTag("lokela_bottom_nav"),
    containerColor = MaterialTheme.colorScheme.surface,
    tonalElevation = 8.dp
  ) {
    NavigationBarItem(
      selected = currentTab == ScreenTab.HOME,
      onClick = { onTabSelected(ScreenTab.HOME) },
      icon = {
        Icon(
          imageVector = if (currentTab == ScreenTab.HOME) Icons.Filled.Home else Icons.Outlined.Home,
          contentDescription = "Home"
        )
      },
      label = { Text("Home") },
      modifier = Modifier.testTag("nav_tab_home"),
      colors = NavigationBarItemDefaults.colors(
        selectedIconColor = LokelaViolet,
        indicatorColor = MaterialTheme.colorScheme.surfaceVariant
      )
    )

    NavigationBarItem(
      selected = currentTab == ScreenTab.EXPLORE,
      onClick = { onTabSelected(ScreenTab.EXPLORE) },
      icon = {
        Icon(
          imageVector = if (currentTab == ScreenTab.EXPLORE) Icons.Filled.Search else Icons.Outlined.Search,
          contentDescription = "Explore"
        )
      },
      label = { Text("Explore") },
      modifier = Modifier.testTag("nav_tab_explore"),
      colors = NavigationBarItemDefaults.colors(
        selectedIconColor = LokelaViolet,
        indicatorColor = MaterialTheme.colorScheme.surfaceVariant
      )
    )

    // Center Create action button with vibrant gradient
    NavigationBarItem(
      selected = currentTab == ScreenTab.CREATE,
      onClick = { onTabSelected(ScreenTab.CREATE) },
      icon = {
        Box(
          modifier = Modifier
            .size(38.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(
              Brush.linearGradient(
                colors = listOf(LokelaViolet, LokelaCoral)
              )
            ),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = Icons.Filled.Add,
            contentDescription = "Create",
            tint = Color.White
          )
        }
      },
      label = { Text("Create") },
      modifier = Modifier.testTag("nav_tab_create")
    )

    NavigationBarItem(
      selected = currentTab == ScreenTab.SHORTS,
      onClick = { onTabSelected(ScreenTab.SHORTS) },
      icon = {
        Icon(
          imageVector = if (currentTab == ScreenTab.SHORTS) Icons.Filled.PlayCircle else Icons.Outlined.PlayCircleOutline,
          contentDescription = "Shorts"
        )
      },
      label = { Text("Shorts") },
      modifier = Modifier.testTag("nav_tab_shorts"),
      colors = NavigationBarItemDefaults.colors(
        selectedIconColor = LokelaCoral,
        indicatorColor = MaterialTheme.colorScheme.surfaceVariant
      )
    )

    NavigationBarItem(
      selected = currentTab == ScreenTab.PROFILE,
      onClick = { onTabSelected(ScreenTab.PROFILE) },
      icon = {
        Icon(
          imageVector = if (currentTab == ScreenTab.PROFILE) Icons.Filled.Person else Icons.Outlined.Person,
          contentDescription = "Profile"
        )
      },
      label = { Text("Profile") },
      modifier = Modifier.testTag("nav_tab_profile"),
      colors = NavigationBarItemDefaults.colors(
        selectedIconColor = LokelaViolet,
        indicatorColor = MaterialTheme.colorScheme.surfaceVariant
      )
    )
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CommentsBottomSheet(
  comments: List<Comment>,
  onDismiss: () -> Unit,
  onAddComment: (String) -> Unit
) {
  var commentInput by remember { mutableStateOf("") }

  ModalBottomSheet(
    onDismissRequest = onDismiss,
    sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
    containerColor = MaterialTheme.colorScheme.surface
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp)
        .padding(bottom = 24.dp)
    ) {
      Text(
        text = "Comments (${comments.size})",
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(bottom = 12.dp)
      )

      Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))

      LazyColumn(
        modifier = Modifier
          .weight(1f, fill = false)
          .heightIn(max = 350.dp)
          .padding(vertical = 8.dp)
      ) {
        if (comments.isEmpty()) {
          item {
            Box(
              modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
              contentAlignment = Alignment.Center
            ) {
              Text(
                text = "Be the first to share your thoughts ✨",
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }
        } else {
          items(comments, key = { it.id }) { comment ->
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
              verticalAlignment = Alignment.Top
            ) {
              AsyncImage(
                model = comment.userAvatar.ifEmpty { "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=400" },
                contentDescription = comment.username,
                modifier = Modifier
                  .size(36.dp)
                  .clip(CircleShape),
                contentScale = ContentScale.Crop
              )
              Spacer(modifier = Modifier.width(12.dp))
              Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Text(
                    text = comment.username,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                  )
                  Spacer(modifier = Modifier.width(8.dp))
                  Text(
                    text = "• 2h",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                  )
                }
                Text(
                  text = comment.content,
                  fontSize = 14.sp,
                  modifier = Modifier.padding(top = 2.dp)
                )
              }
              IconButton(
                onClick = {},
                modifier = Modifier.size(32.dp)
              ) {
                Icon(
                  imageVector = Icons.Outlined.FavoriteBorder,
                  contentDescription = "Like comment",
                  modifier = Modifier.size(16.dp),
                  tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
              }
            }
          }
        }
      }

      // Input row
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(top = 8.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        OutlinedTextField(
          value = commentInput,
          onValueChange = { commentInput = it },
          placeholder = { Text("Add a comment on Lokela...") },
          modifier = Modifier
            .weight(1f)
            .testTag("comment_input_field"),
          shape = RoundedCornerShape(24.dp),
          singleLine = true,
          colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = LokelaViolet,
            unfocusedBorderColor = MaterialTheme.colorScheme.outline
          )
        )
        Spacer(modifier = Modifier.width(8.dp))
        IconButton(
          onClick = {
            if (commentInput.isNotBlank()) {
              onAddComment(commentInput.trim())
              commentInput = ""
            }
          },
          modifier = Modifier
            .size(48.dp)
            .clip(CircleShape)
            .background(LokelaViolet)
            .testTag("send_comment_button")
        ) {
          Icon(
            imageVector = Icons.AutoMirrored.Filled.Send,
            contentDescription = "Send",
            tint = Color.White
          )
        }
      }
    }
  }
}

@Composable
fun ReportDialog(
  targetTitle: String,
  onDismiss: () -> Unit,
  onConfirm: (reason: String) -> Unit
) {
  val reasons = listOf(
    "Spam or misleading",
    "Inappropriate content",
    "Harassment or hate speech",
    "Copyright violation",
    "Violence or harmful behavior"
  )
  var selectedReason by remember { mutableStateOf(reasons.first()) }

  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text("Report $targetTitle") },
    text = {
      Column {
        Text(
          text = "Help us keep the Lokela community safe and creative. Select a reason:",
          style = MaterialTheme.typography.bodyMedium,
          modifier = Modifier.padding(bottom = 12.dp)
        )
        reasons.forEach { reason ->
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .clickable { selectedReason = reason }
              .padding(vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            RadioButton(
              selected = (reason == selectedReason),
              onClick = { selectedReason = reason },
              colors = RadioButtonDefaults.colors(selectedColor = LokelaCoral)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(text = reason, fontSize = 14.sp)
          }
        }
      }
    },
    confirmButton = {
      Button(
        onClick = { onConfirm(selectedReason) },
        colors = ButtonDefaults.buttonColors(containerColor = LokelaCoral),
        modifier = Modifier.testTag("confirm_report_button")
      ) {
        Text("Submit Report")
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) {
        Text("Cancel")
      }
    }
  )
}
