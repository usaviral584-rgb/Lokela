package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.Comment
import com.example.data.model.Post
import com.example.data.repository.LokelaRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class FeedViewModel(application: Application) : AndroidViewModel(application) {
  val repository = LokelaRepository(application)

  val posts: StateFlow<List<Post>> = repository.posts.stateIn(
    scope = viewModelScope,
    started = SharingStarted.WhileSubscribed(5000),
    initialValue = emptyList()
  )

  private val _isRefreshing = MutableStateFlow(false)
  val isRefreshing: StateFlow<Boolean> = _isRefreshing.asStateFlow()

  // Comments for a selected post in bottom sheet
  private val _selectedPostComments = MutableStateFlow<List<Comment>>(emptyList())
  val selectedPostComments: StateFlow<List<Comment>> = _selectedPostComments.asStateFlow()

  private val _activeCommentPostId = MutableStateFlow<String?>(null)
  val activeCommentPostId: StateFlow<String?> = _activeCommentPostId.asStateFlow()

  fun refreshFeed() {
    viewModelScope.launch {
      _isRefreshing.value = true
      // Simulate network refresh
      kotlinx.coroutines.delay(800)
      _isRefreshing.value = false
    }
  }

  fun toggleLike(postId: String) {
    viewModelScope.launch {
      repository.toggleLikePost(postId)
    }
  }

  fun toggleSave(postId: String) {
    viewModelScope.launch {
      repository.toggleSavePost(postId)
    }
  }

  fun deletePost(postId: String) {
    viewModelScope.launch {
      repository.deletePost(postId)
    }
  }

  fun openComments(postId: String) {
    _activeCommentPostId.value = postId
    // Seed initial comments for demo
    _selectedPostComments.value = listOf(
      Comment(
        id = "c1",
        postId = postId,
        userId = "u_marcus",
        username = "marcus_design",
        userDisplayName = "Marcus Vance",
        userAvatar = "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400",
        content = "The lighting and mood here is pure inspiration! 🔥",
        timestamp = System.currentTimeMillis() - 1800000,
        likeCount = 14,
        isLiked = false,
        repliesCount = 1
      ),
      Comment(
        id = "c2",
        postId = postId,
        userId = "u_elena",
        username = "elena_craft",
        userDisplayName = "Elena Rostova",
        userAvatar = "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400",
        content = "Lokela is shaping up to be such a vibrant creative space ✨",
        timestamp = System.currentTimeMillis() - 7200000,
        likeCount = 8,
        isLiked = true,
        repliesCount = 0
      )
    )
  }

  fun closeComments() {
    _activeCommentPostId.value = null
  }

  fun addComment(text: String) {
    val postId = _activeCommentPostId.value ?: return
    if (text.isBlank()) return
    val me = repository.currentUser.value
    val newComment = Comment(
      id = "c_" + System.currentTimeMillis(),
      postId = postId,
      userId = me.id,
      username = me.username,
      userDisplayName = me.displayName,
      userAvatar = me.avatarUrl,
      content = text,
      timestamp = System.currentTimeMillis(),
      likeCount = 0,
      isLiked = false
    )
    _selectedPostComments.value = listOf(newComment) + _selectedPostComments.value
  }
}
