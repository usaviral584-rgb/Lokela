package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.example.data.model.MediaType
import com.example.data.model.Post
import com.example.ui.components.CommentsBottomSheet
import com.example.ui.components.LokelaTopAppBar
import com.example.ui.components.ReportDialog
import com.example.ui.theme.*
import com.example.ui.viewmodel.FeedViewModel

@Composable
fun HomeScreen(
  feedViewModel: FeedViewModel,
  onOpenNotifications: () -> Unit,
  onOpenMessages: () -> Unit,
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current
  val posts by feedViewModel.posts.collectAsStateWithLifecycle()
  val isRefreshing by feedViewModel.isRefreshing.collectAsStateWithLifecycle()
  val activeCommentPostId by feedViewModel.activeCommentPostId.collectAsStateWithLifecycle()
  val comments by feedViewModel.selectedPostComments.collectAsStateWithLifecycle()

  var reportingPost by remember { mutableStateOf<Post?>(null) }

  Scaffold(
    modifier = modifier.testTag("home_screen"),
    topBar = {
      LokelaTopAppBar(
        onNotificationsClick = onOpenNotifications,
        onMessagesClick = onOpenMessages
      )
    }
  ) { innerPadding ->
    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding)
        .testTag("feed_lazy_column")
    ) {
      // Stories / Creator Spotlights Tray
      item {
        StoriesTray(
          onStoryClick = { name ->
            Toast.makeText(context, "Viewing $name's Lokela story", Toast.LENGTH_SHORT).show()
          }
        )
      }

      if (posts.isEmpty()) {
        item {
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .padding(48.dp),
            contentAlignment = Alignment.Center
          ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
              Icon(
                imageVector = Icons.Outlined.PhotoCamera,
                contentDescription = "No posts",
                modifier = Modifier.size(64.dp),
                tint = MaterialTheme.colorScheme.outline
              )
              Spacer(modifier = Modifier.height(16.dp))
              Text(
                text = "Welcome to your Lokela Feed",
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.titleMedium
              )
              Text(
                text = "Follow creators or share your first original moment!",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 13.sp,
                modifier = Modifier.padding(top = 4.dp)
              )
            }
          }
        }
      } else {
        items(posts, key = { it.id }) { post ->
          PostCard(
            post = post,
            onLikeClick = { feedViewModel.toggleLike(post.id) },
            onCommentClick = { feedViewModel.openComments(post.id) },
            onSaveClick = { feedViewModel.toggleSave(post.id) },
            onShareClick = {
              Toast.makeText(context, "Sharing post link: lokela.social/p/${post.id}", Toast.LENGTH_SHORT).show()
            },
            onReportClick = { reportingPost = post },
            onDeleteClick = { feedViewModel.deletePost(post.id) }
          )
        }
      }
    }
  }

  // Comments Bottom Sheet
  if (activeCommentPostId != null) {
    CommentsBottomSheet(
      comments = comments,
      onDismiss = { feedViewModel.closeComments() },
      onAddComment = { text -> feedViewModel.addComment(text) }
    )
  }

  // Report Content Dialog
  reportingPost?.let { post ->
    ReportDialog(
      targetTitle = "Post by @${post.username}",
      onDismiss = { reportingPost = null },
      onConfirm = { reason ->
        reportingPost = null
        Toast.makeText(context, "Report received: $reason. Thank you.", Toast.LENGTH_LONG).show()
      }
    )
  }
}

@Composable
fun StoriesTray(onStoryClick: (String) -> Unit) {
  val stories = listOf(
    StoryItem("Your Story", "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400", isMe = true),
    StoryItem("elena_craft", "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400"),
    StoryItem("marcus_design", "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400"),
    StoryItem("sarah_travels", "https://images.unsplash.com/photo-1517841905240-472988babdf9?w=400"),
    StoryItem("kai_tanaka", "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400")
  )

  LazyRow(
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 12.dp),
    contentPadding = PaddingValues(horizontal = 16.dp),
    horizontalArrangement = Arrangement.spacedBy(14.dp)
  ) {
    items(stories) { item ->
      Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
          .clickable { onStoryClick(item.name) }
          .testTag("story_item_${item.name}")
      ) {
        Box(
          modifier = Modifier
            .size(68.dp)
            .clip(CircleShape)
            .background(
              if (item.isMe) Brush.linearGradient(listOf(LokelaAmber, LokelaCoral))
              else Brush.linearGradient(listOf(LokelaViolet, LokelaCoral))
            )
            .padding(2.5.dp),
          contentAlignment = Alignment.Center
        ) {
          AsyncImage(
            model = item.avatar,
            contentDescription = item.name,
            modifier = Modifier
              .fillMaxSize()
              .clip(CircleShape),
            contentScale = ContentScale.Crop
          )
          if (item.isMe) {
            Box(
              modifier = Modifier
                .align(Alignment.BottomEnd)
                .size(20.dp)
                .clip(CircleShape)
                .background(LokelaViolet)
                .border(2.dp, MaterialTheme.colorScheme.background, CircleShape),
              contentAlignment = Alignment.Center
            ) {
              Icon(
                imageVector = Icons.Filled.Add,
                contentDescription = "Add Story",
                tint = Color.White,
                modifier = Modifier.size(12.dp)
              )
            }
          }
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(
          text = item.name,
          fontSize = 11.sp,
          fontWeight = FontWeight.Medium,
          maxLines = 1
        )
      }
    }
  }
}

data class StoryItem(val name: String, val avatar: String, val isMe: Boolean = false)

@Composable
fun PostCard(
  post: Post,
  onLikeClick: () -> Unit,
  onCommentClick: () -> Unit,
  onSaveClick: () -> Unit,
  onShareClick: () -> Unit,
  onReportClick: () -> Unit,
  onDeleteClick: () -> Unit
) {
  var menuExpanded by remember { mutableStateOf(false) }

  Card(
    modifier = Modifier
      .fillMaxWidth()
      .padding(horizontal = 12.dp, vertical = 8.dp)
      .testTag("post_card_${post.id}"),
    shape = RoundedCornerShape(18.dp),
    colors = CardDefaults.cardColors(
      containerColor = MaterialTheme.colorScheme.surface
    ),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
  ) {
    Column {
      // Header: Creator details + options
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        AsyncImage(
          model = post.userAvatar.ifEmpty { "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=400" },
          contentDescription = post.username,
          modifier = Modifier
            .size(42.dp)
            .clip(CircleShape),
          contentScale = ContentScale.Crop
        )
        Spacer(modifier = Modifier.width(10.dp))
        Column(modifier = Modifier.weight(1f)) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
              text = post.userDisplayName.ifEmpty { post.username },
              fontWeight = FontWeight.Bold,
              fontSize = 14.sp
            )
            Spacer(modifier = Modifier.width(4.dp))
            Icon(
              imageVector = Icons.Filled.CheckCircle,
              contentDescription = "Verified",
              tint = LokelaViolet,
              modifier = Modifier.size(14.dp)
            )
          }
          if (post.location.isNotBlank()) {
            Text(
              text = post.location,
              fontSize = 12.sp,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }

        Box {
          IconButton(
            onClick = { menuExpanded = true },
            modifier = Modifier.size(36.dp)
          ) {
            Icon(
              imageVector = Icons.Filled.MoreVert,
              contentDescription = "Options",
              tint = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }

          DropdownMenu(
            expanded = menuExpanded,
            onDismissRequest = { menuExpanded = false }
          ) {
            DropdownMenuItem(
              text = { Text("Report Post") },
              leadingIcon = { Icon(Icons.Outlined.Report, contentDescription = null, tint = LokelaCoral) },
              onClick = {
                menuExpanded = false
                onReportClick()
              }
            )
            DropdownMenuItem(
              text = { Text("Delete Post") },
              leadingIcon = { Icon(Icons.Outlined.Delete, contentDescription = null) },
              onClick = {
                menuExpanded = false
                onDeleteClick()
              }
            )
          }
        }
      }

      // Post Media (Single or Multiple with Pager)
      if (post.mediaUrls.isNotEmpty()) {
        val pagerState = rememberPagerState(pageCount = { post.mediaUrls.size })
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .height(360.dp)
            .clip(RoundedCornerShape(12.dp))
        ) {
          HorizontalPager(
            state = pagerState,
            modifier = Modifier.fillMaxSize()
          ) { page ->
            AsyncImage(
              model = post.mediaUrls[page],
              contentDescription = "Post image ${page + 1}",
              modifier = Modifier.fillMaxSize(),
              contentScale = ContentScale.Crop
            )
          }

          if (post.mediaUrls.size > 1) {
            // Pill indicator
            Box(
              modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(12.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(Color.Black.copy(alpha = 0.6f))
                .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
              Text(
                text = "${pagerState.currentPage + 1}/${post.mediaUrls.size}",
                color = Color.White,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
              )
            }
          }
        }
      }

      // Interaction Action Bar
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 8.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        val likeTint by animateColorAsState(
          targetValue = if (post.isLiked) LokelaCoral else MaterialTheme.colorScheme.onSurface,
          animationSpec = spring(),
          label = "likeColor"
        )
        IconButton(
          onClick = onLikeClick,
          modifier = Modifier.testTag("like_button_${post.id}")
        ) {
          Icon(
            imageVector = if (post.isLiked) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
            contentDescription = "Like",
            tint = likeTint
          )
        }

        IconButton(
          onClick = onCommentClick,
          modifier = Modifier.testTag("comment_button_${post.id}")
        ) {
          Icon(
            imageVector = Icons.Outlined.ModeComment,
            contentDescription = "Comment",
            tint = MaterialTheme.colorScheme.onSurface
          )
        }

        IconButton(
          onClick = onShareClick,
          modifier = Modifier.testTag("share_button_${post.id}")
        ) {
          Icon(
            imageVector = Icons.Outlined.Share,
            contentDescription = "Share",
            tint = MaterialTheme.colorScheme.onSurface
          )
        }

        Spacer(modifier = Modifier.weight(1f))

        IconButton(
          onClick = onSaveClick,
          modifier = Modifier.testTag("save_button_${post.id}")
        ) {
          Icon(
            imageVector = if (post.isSaved) Icons.Filled.Bookmark else Icons.Outlined.BookmarkBorder,
            contentDescription = "Save",
            tint = if (post.isSaved) LokelaViolet else MaterialTheme.colorScheme.onSurface
          )
        }
      }

      // Like count & Caption & Tags
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 14.dp)
          .padding(bottom = 12.dp)
      ) {
        if (post.likeCount > 0) {
          Text(
            text = "${post.likeCount} likes",
            fontWeight = FontWeight.Bold,
            fontSize = 13.sp
          )
        }

        if (post.caption.isNotBlank()) {
          Row(modifier = Modifier.padding(top = 4.dp)) {
            Text(
              text = post.username + " ",
              fontWeight = FontWeight.Bold,
              fontSize = 13.sp
            )
            Text(
              text = post.caption,
              fontSize = 13.sp,
              lineHeight = 18.sp
            )
          }
        }

        if (post.commentCount > 0) {
          Text(
            text = "View all ${post.commentCount} comments",
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier
              .padding(top = 6.dp)
              .clickable { onCommentClick() }
          )
        }
      }
    }
  }
}
