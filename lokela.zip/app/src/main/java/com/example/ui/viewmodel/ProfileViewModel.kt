package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.Post
import com.example.data.model.ShortVideo
import com.example.data.model.User
import com.example.data.repository.LokelaRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class ProfileTab {
  POSTS,
  SHORTS,
  SAVED
}

class ProfileViewModel(application: Application) : AndroidViewModel(application) {
  val repository = LokelaRepository(application)

  val currentUser: StateFlow<User> = repository.currentUser

  private val _selectedTab = MutableStateFlow(ProfileTab.POSTS)
  val selectedTab: StateFlow<ProfileTab> = _selectedTab.asStateFlow()

  val myPosts: StateFlow<List<Post>> = repository.posts.map { list ->
    list.filter { it.userId == currentUser.value.id || it.username == currentUser.value.username }
  }.stateIn(
    scope = viewModelScope,
    started = SharingStarted.WhileSubscribed(5000),
    initialValue = emptyList()
  )

  val mySavedPosts: StateFlow<List<Post>> = repository.posts.map { list ->
    list.filter { it.isSaved }
  }.stateIn(
    scope = viewModelScope,
    started = SharingStarted.WhileSubscribed(5000),
    initialValue = emptyList()
  )

  val myShorts: StateFlow<List<ShortVideo>> = repository.shorts.map { list ->
    list.filter { it.userId == currentUser.value.id || it.username == currentUser.value.username }
  }.stateIn(
    scope = viewModelScope,
    started = SharingStarted.WhileSubscribed(5000),
    initialValue = emptyList()
  )

  fun selectTab(tab: ProfileTab) {
    _selectedTab.value = tab
  }

  fun updateProfile(displayName: String, bio: String, avatarUrl: String) {
    viewModelScope.launch {
      repository.updateProfile(displayName, bio, avatarUrl)
    }
  }

  fun logout() {
    viewModelScope.launch {
      repository.logout()
    }
  }

  fun deleteAccount() {
    viewModelScope.launch {
      repository.deleteAccount()
    }
  }
}
