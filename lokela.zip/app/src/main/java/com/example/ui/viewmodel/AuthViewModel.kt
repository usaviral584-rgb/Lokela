package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.repository.LokelaRepository
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

enum class AuthMode {
  LOGIN,
  REGISTER,
  VERIFY_OTP,
  FORGOT_PASSWORD
}

class AuthViewModel(application: Application) : AndroidViewModel(application) {
  val repository = LokelaRepository(application)

  val isLoggedIn: StateFlow<Boolean> = repository.isLoggedIn

  private val _authMode = MutableStateFlow(AuthMode.LOGIN)
  val authMode: StateFlow<AuthMode> = _authMode.asStateFlow()

  private val _email = MutableStateFlow("")
  val email: StateFlow<String> = _email.asStateFlow()

  private val _password = MutableStateFlow("")
  val password: StateFlow<String> = _password.asStateFlow()

  private val _username = MutableStateFlow("")
  val username: StateFlow<String> = _username.asStateFlow()

  private val _displayName = MutableStateFlow("")
  val displayName: StateFlow<String> = _displayName.asStateFlow()

  private val _otpCode = MutableStateFlow("")
  val otpCode: StateFlow<String> = _otpCode.asStateFlow()

  private val _isLoading = MutableStateFlow(false)
  val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

  private val _errorMessage = MutableStateFlow<String?>(null)
  val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

  private val _otpTimer = MutableStateFlow(60)
  val otpTimer: StateFlow<Int> = _otpTimer.asStateFlow()

  fun setAuthMode(mode: AuthMode) {
    _authMode.value = mode
    _errorMessage.value = null
  }

  fun setEmail(value: String) { _email.value = value }
  fun setPassword(value: String) { _password.value = value }
  fun setUsername(value: String) { _username.value = value }
  fun setDisplayName(value: String) { _displayName.value = value }
  fun setOtpCode(value: String) { _otpCode.value = value }

  fun login() {
    if (_email.value.isBlank() || _password.value.isBlank()) {
      _errorMessage.value = "Please fill in all credentials"
      return
    }
    viewModelScope.launch {
      _isLoading.value = true
      _errorMessage.value = null
      delay(500)
      val success = repository.login(_email.value, _password.value)
      _isLoading.value = false
      if (!success) {
        _errorMessage.value = "Invalid email or password"
      }
    }
  }

  fun register() {
    if (_email.value.isBlank() || _password.value.isBlank() || _username.value.isBlank()) {
      _errorMessage.value = "Please provide username, email and password"
      return
    }
    viewModelScope.launch {
      _isLoading.value = true
      _errorMessage.value = null
      delay(600)
      _authMode.value = AuthMode.VERIFY_OTP
      _isLoading.value = false
      startOtpCountdown()
    }
  }

  fun verifyOtp() {
    if (_otpCode.value.length < 4) {
      _errorMessage.value = "Please enter valid verification code"
      return
    }
    viewModelScope.launch {
      _isLoading.value = true
      delay(500)
      val success = repository.register(
        _email.value,
        _password.value,
        _username.value,
        _displayName.value
      )
      _isLoading.value = false
      if (!success) {
        _errorMessage.value = "Failed to complete registration"
      }
    }
  }

  fun sendPasswordReset() {
    if (_email.value.isBlank()) {
      _errorMessage.value = "Enter your registered email address"
      return
    }
    viewModelScope.launch {
      _isLoading.value = true
      delay(600)
      _isLoading.value = false
      _errorMessage.value = "Password reset link sent to ${_email.value}"
    }
  }

  private fun startOtpCountdown() {
    viewModelScope.launch {
      _otpTimer.value = 60
      while (_otpTimer.value > 0) {
        delay(1000)
        _otpTimer.value -= 1
      }
    }
  }
}
