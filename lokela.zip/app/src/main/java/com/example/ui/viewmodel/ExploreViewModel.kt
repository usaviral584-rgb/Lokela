package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.Post
import com.example.data.model.TrendingTopic
import com.example.data.model.User
import com.example.data.repository.LokelaRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn

class ExploreViewModel(application: Application) : AndroidViewModel(application) {
  private val repository = LokelaRepository(application)

  private val _searchQuery = MutableStateFlow("")
  val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

  private val _selectedCategory = MutableStateFlow("All")
  val selectedCategory: StateFlow<String> = _selectedCategory.asStateFlow()

  val categories = listOf("All", "Photography", "Art & Design", "Sound & Music", "Travel", "Tech", "Lifestyle")

  val trendingTopics = MutableStateFlow(
    listOf(
      TrendingTopic("#LokelaOriginal", "128.4K posts", "Community"),
      TrendingTopic("#TokyoTwilight", "84.2K posts", "Travel"),
      TrendingTopic("#MinimalistStudio", "62.1K posts", "Design"),
      TrendingTopic("#GenerativeBeats", "45.9K posts", "Music"),
      TrendingTopic("#AmalfiCoast", "31.7K posts", "Photography")
    )
  )

  val suggestedUsers = MutableStateFlow(
    listOf(
      User(
        id = "u_synth",
        username = "synth_horizon",
        displayName = "Synth Horizon",
        avatarUrl = "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400",
        bio = "Analog warmth meets digital pulses 🎹",
        followersCount = 8900
      ),
      User(
        id = "u_tokyo",
        username = "tokyo_urban",
        displayName = "Kenji Sato",
        avatarUrl = "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400",
        bio = "Street & night photography in Shibuya 📸",
        followersCount = 15400
      )
    )
  )

  val explorePosts: StateFlow<List<Post>> = combine(
    repository.posts,
    _searchQuery,
    _selectedCategory
  ) { posts, query, category ->
    posts.filter { post ->
      val matchesQuery = query.isBlank() ||
        post.caption.contains(query, ignoreCase = true) ||
        post.username.contains(query, ignoreCase = true) ||
        post.hashtags.any { it.contains(query, ignoreCase = true) }
      val matchesCategory = category == "All" || post.caption.contains(category.take(4), ignoreCase = true)
      matchesQuery && matchesCategory
    }
  }.stateIn(
    scope = viewModelScope,
    started = SharingStarted.WhileSubscribed(5000),
    initialValue = emptyList()
  )

  fun onSearchQueryChanged(newQuery: String) {
    _searchQuery.value = newQuery
  }

  fun selectCategory(category: String) {
    _selectedCategory.value = category
  }
}
