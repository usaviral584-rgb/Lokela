package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val LokelaDarkColorScheme = darkColorScheme(
  primary = LokelaVioletLight,
  onPrimary = Color.White,
  primaryContainer = LokelaVioletDark,
  onPrimaryContainer = Color.White,
  secondary = LokelaCoral,
  onSecondary = Color.White,
  secondaryContainer = Color(0xFF5E1220),
  onSecondaryContainer = LokelaCoralLight,
  tertiary = LokelaAmber,
  background = LokelaDarkBackground,
  onBackground = LokelaDarkOnSurface,
  surface = LokelaDarkSurface,
  onSurface = LokelaDarkOnSurface,
  surfaceVariant = LokelaDarkSurfaceVariant,
  onSurfaceVariant = LokelaDarkOnSurfaceSubtle,
  outline = LokelaDarkOutline,
)

private val LokelaLightColorScheme = lightColorScheme(
  primary = LokelaViolet,
  onPrimary = Color.White,
  primaryContainer = Color(0xFFEDE9FE),
  onPrimaryContainer = LokelaVioletDark,
  secondary = LokelaCoral,
  onSecondary = Color.White,
  secondaryContainer = Color(0xFFFFE4E8),
  onSecondaryContainer = Color(0xFF9F1239),
  tertiary = LokelaAmber,
  background = LokelaLightBackground,
  onBackground = LokelaLightOnSurface,
  surface = LokelaLightSurface,
  onSurface = LokelaLightOnSurface,
  surfaceVariant = LokelaLightSurfaceVariant,
  onSurfaceVariant = LokelaLightOnSurfaceSubtle,
  outline = LokelaLightOutline,
)

@Composable
fun LokelaTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  dynamicColor: Boolean = false, // Lokela brand colors take priority for distinctive identity
  content: @Composable () -> Unit,
) {
  val colorScheme = when {
    dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
      val context = LocalContext.current
      if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
    }
    darkTheme -> LokelaDarkColorScheme
    else -> LokelaLightColorScheme
  }

  MaterialTheme(
    colorScheme = colorScheme,
    typography = Typography,
    content = content
  )
}

// Alias for template backwards compatibility
@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  LokelaTheme(darkTheme = darkTheme, dynamicColor = dynamicColor, content = content)
}

