package com.example.ui.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.MediaType
import com.example.data.repository.LokelaRepository
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

enum class CreateMode {
  PHOTO_POST,
  MULTI_PHOTO,
  SHORT_VIDEO
}

class CreatePostViewModel(application: Application) : AndroidViewModel(application) {
  val repository = LokelaRepository(application)

  private val _mode = MutableStateFlow(CreateMode.PHOTO_POST)
  val mode: StateFlow<CreateMode> = _mode.asStateFlow()

  private val _caption = MutableStateFlow("")
  val caption: StateFlow<String> = _caption.asStateFlow()

  private val _location = MutableStateFlow("")
  val location: StateFlow<String> = _location.asStateFlow()

  private val _privacy = MutableStateFlow("Public")
  val privacy: StateFlow<String> = _privacy.asStateFlow()

  private val _selectedMediaUris = MutableStateFlow<List<Uri>>(emptyList())
  val selectedMediaUris: StateFlow<List<Uri>> = _selectedMediaUris.asStateFlow()

  private val _isUploading = MutableStateFlow(false)
  val isUploading: StateFlow<Boolean> = _isUploading.asStateFlow()

  private val _uploadProgress = MutableStateFlow(0f)
  val uploadProgress: StateFlow<Float> = _uploadProgress.asStateFlow()

  private val _uploadSuccess = MutableStateFlow(false)
  val uploadSuccess: StateFlow<Boolean> = _uploadSuccess.asStateFlow()

  fun setMode(newMode: CreateMode) {
    _mode.value = newMode
  }

  fun setCaption(text: String) {
    _caption.value = text
  }

  fun setLocation(loc: String) {
    _location.value = loc
  }

  fun setPrivacy(priv: String) {
    _privacy.value = priv
  }

  fun addMediaUri(uri: Uri) {
    _selectedMediaUris.value = _selectedMediaUris.value + uri
  }

  fun setMediaUris(uris: List<Uri>) {
    _selectedMediaUris.value = uris
  }

  fun removeMediaUri(uri: Uri) {
    _selectedMediaUris.value = _selectedMediaUris.value.filter { it != uri }
  }

  fun publishPost(onComplete: () -> Unit) {
    if (_isUploading.value) return

    viewModelScope.launch {
      _isUploading.value = true
      _uploadProgress.value = 0.1f

      // Compress and optimize media progress simulation
      delay(300)
      _uploadProgress.value = 0.45f
      delay(350)
      _uploadProgress.value = 0.85f
      delay(250)
      _uploadProgress.value = 1.0f

      // Extract hashtags from caption
      val hashtags = _caption.value.split(" ", "\n")
        .filter { it.startsWith("#") }
        .map { it.removePrefix("#") }

      val mediaUrisStrings = _selectedMediaUris.value.map { it.toString() }

      if (_mode.value == CreateMode.SHORT_VIDEO) {
        repository.createShort(
          caption = _caption.value.ifBlank { "Original Lokela Short" },
          videoUrl = mediaUrisStrings.firstOrNull() ?: "",
          thumbnailUrl = "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=800",
          soundTrack = "Original Audio - " + repository.currentUser.value.displayName
        )
      } else {
        val mediaType = if (_selectedMediaUris.value.size > 1) MediaType.MULTI_IMAGE else MediaType.IMAGE
        repository.createPost(
          caption = _caption.value.ifBlank { "New Lokela post ✨" },
          mediaUrls = mediaUrisStrings,
          mediaType = mediaType,
          location = _location.value,
          hashtags = hashtags,
          privacy = _privacy.value.lowercase()
        )
      }

      _isUploading.value = false
      _uploadSuccess.value = true
      // Reset form
      _caption.value = ""
      _location.value = ""
      _selectedMediaUris.value = emptyList()
      onComplete()
    }
  }

  fun resetUploadState() {
    _uploadSuccess.value = false
    _uploadProgress.value = 0f
  }
}
