package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Lokela Palette: Electric Violet, Deep Indigo, and Coral Sunset
val LokelaViolet = Color(0xFF7C3AED)
val LokelaVioletLight = Color(0xFFA78BFA)
val LokelaVioletDark = Color(0xFF5B21B6)

val LokelaIndigo = Color(0xFF4F46E5)
val LokelaCoral = Color(0xFFFF5269)
val LokelaCoralLight = Color(0xFFFF7A8D)
val LokelaAmber = Color(0xFFFBBF24)
val LokelaTeal = Color(0xFF10B981)

// Dark Theme Surfaces (Lokela Midnight Cosmic)
val LokelaDarkBackground = Color(0xFF0C0A15)
val LokelaDarkSurface = Color(0xFF161326)
val LokelaDarkSurfaceVariant = Color(0xFF221E38)
val LokelaDarkOutline = Color(0xFF332E52)
val LokelaDarkOnSurface = Color(0xFFF3F0FA)
val LokelaDarkOnSurfaceSubtle = Color(0xFF9E98B3)

// Light Theme Surfaces
val LokelaLightBackground = Color(0xFFF9F8FD)
val LokelaLightSurface = Color(0xFFFFFFFF)
val LokelaLightSurfaceVariant = Color(0xFFF2EFFB)
val LokelaLightOutline = Color(0xFFE2DCF0)
val LokelaLightOnSurface = Color(0xFF151221)
val LokelaLightOnSurfaceSubtle = Color(0xFF6B6580)

