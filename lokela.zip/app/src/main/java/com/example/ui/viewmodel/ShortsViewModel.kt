package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.ShortVideo
import com.example.data.repository.LokelaRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ShortsViewModel(application: Application) : AndroidViewModel(application) {
  val repository = LokelaRepository(application)

  val shorts: StateFlow<List<ShortVideo>> = repository.shorts.stateIn(
    scope = viewModelScope,
    started = SharingStarted.WhileSubscribed(5000),
    initialValue = emptyList()
  )

  private val _currentIndex = MutableStateFlow(0)
  val currentIndex: StateFlow<Int> = _currentIndex.asStateFlow()

  private val _isPlaying = MutableStateFlow(true)
  val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

  fun setCurrentIndex(index: Int) {
    _currentIndex.value = index
  }

  fun togglePlayPause() {
    _isPlaying.value = !_isPlaying.value
  }

  fun toggleLike(short: ShortVideo) {
    viewModelScope.launch {
      repository.toggleLikeShort(short.id, short.isLiked)
    }
  }

  fun toggleFollow(userId: String, isFollowing: Boolean) {
    viewModelScope.launch {
      repository.toggleFollowUser(userId, isFollowing)
    }
  }
}
