package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.Conversation
import com.example.data.model.Message
import com.example.data.model.User
import com.example.data.repository.LokelaRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MessagingViewModel(application: Application) : AndroidViewModel(application) {
  val repository = LokelaRepository(application)

  private val _conversations = MutableStateFlow(
    listOf(
      Conversation(
        id = "conv_1",
        peerUser = User(
          id = "u_marcus",
          username = "marcus_design",
          displayName = "Marcus Vance",
          avatarUrl = "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400",
          bio = "Lead Visual Designer",
          isVerified = true
        ),
        lastMessage = "Hey Alex! Loved your new series on Lokela.",
        lastTimestamp = System.currentTimeMillis() - 1800000,
        unreadCount = 1,
        isOnline = true
      ),
      Conversation(
        id = "conv_2",
        peerUser = User(
          id = "u_elena",
          username = "elena_craft",
          displayName = "Elena Rostova",
          avatarUrl = "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400",
          bio = "Tokyo Nights series creator",
          isVerified = true
        ),
        lastMessage = "Let's definitely sync on that video edit!",
        lastTimestamp = System.currentTimeMillis() - 86400000,
        unreadCount = 0,
        isOnline = false
      )
    )
  )
  val conversations: StateFlow<List<Conversation>> = _conversations.asStateFlow()

  private val _activeConversationId = MutableStateFlow<String?>("conv_1")
  val activeConversationId: StateFlow<String?> = _activeConversationId.asStateFlow()

  val activeMessages: StateFlow<List<Message>> = repository.getMessages("conv_1").stateIn(
    scope = viewModelScope,
    started = SharingStarted.WhileSubscribed(5000),
    initialValue = emptyList()
  )

  private val _isTyping = MutableStateFlow(false)
  val isTyping: StateFlow<Boolean> = _isTyping.asStateFlow()

  fun selectConversation(convId: String) {
    _activeConversationId.value = convId
  }

  fun sendMessage(convId: String, text: String) {
    if (text.isBlank()) return
    viewModelScope.launch {
      repository.sendMessage(convId, text)
      // Update last message in list
      _conversations.value = _conversations.value.map { conv ->
        if (conv.id == convId) {
          conv.copy(lastMessage = text, lastTimestamp = System.currentTimeMillis(), unreadCount = 0)
        } else conv
      }
    }
  }
}
